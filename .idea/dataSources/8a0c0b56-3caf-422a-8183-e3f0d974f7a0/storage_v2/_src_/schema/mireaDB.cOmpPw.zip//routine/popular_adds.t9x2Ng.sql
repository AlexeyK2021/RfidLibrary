create
    definer = alexey@`%` procedure popular_adds()
BEGIN
SELECT add_service.name, COUNT(*) AS count 
FROM client_add_service 
JOIN add_service ON add_service.add_service_id = client_add_service.add_service 
GROUP BY add_service.add_service_id 
ORDER BY count DESC;
END;

