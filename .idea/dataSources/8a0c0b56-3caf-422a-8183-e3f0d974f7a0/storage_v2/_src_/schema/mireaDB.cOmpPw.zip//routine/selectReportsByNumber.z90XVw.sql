create
    definer = alexey@`%` procedure selectReportsByNumber(IN phone_number text)
BEGIN
SELECT report.*, category.name AS category_name FROM report 
JOIN category ON category.category_id = report.category_id WHERE report.report_id IN (
	SELECT report_id FROM file_storage WHERE client_id = ( 
		SELECT client_id FROM client WHERE phone_number = phone_number ORDER BY client_id LIMIT 1 
	) 
);
END;

