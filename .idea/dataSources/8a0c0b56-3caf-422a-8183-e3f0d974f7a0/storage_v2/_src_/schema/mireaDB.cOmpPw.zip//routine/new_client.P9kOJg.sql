create
    definer = alexey@`%` function new_client(fullname varchar(128), passport varchar(128), login varchar(64),
                                             password varchar(64), phone_number_in varchar(25),
                                             tariff_id int) returns int deterministic
BEGIN
	DECLARE client_id_var INT;
    
	INSERT INTO client(balance, phone_number, account_state, tariff_id)
	VALUE (0, phone_number_in, true, tariff_id);
    
    SET client_id_var = (
		SELECT client_id FROM client 
        WHERE client.phone_number = phone_number_in LIMIT 1
    );
    
    INSERT INTO personal_info(client_id, full_name, passport_data, login, password) 
	VALUE (client_id_var, fullname, passport, login, password);
    
RETURN client_id_var;
END;

