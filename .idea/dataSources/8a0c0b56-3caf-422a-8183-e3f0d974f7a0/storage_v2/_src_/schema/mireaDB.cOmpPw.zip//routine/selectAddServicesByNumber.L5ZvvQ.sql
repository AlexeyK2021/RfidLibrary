create
    definer = alexey@`%` procedure selectAddServicesByNumber(IN number text)
BEGIN
SELECT * FROM add_service WHERE add_service_id IN (
	SELECT add_service FROM client_add_service WHERE client_id = (
		SELECT client_id FROM client WHERE phone_number = number
	));
END;

