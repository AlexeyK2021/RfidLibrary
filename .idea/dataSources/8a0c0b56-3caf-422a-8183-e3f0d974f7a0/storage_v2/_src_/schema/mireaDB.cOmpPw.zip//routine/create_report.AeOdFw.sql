create
    definer = alexey@`%` function create_report(client_id_in int, description_in varchar(500), result_in binary(1),
                                                finish_date_in datetime, category_id_in int) returns int deterministic
BEGIN
	DECLARE report_id_new INT;
    DECLARE file_storage_id INT;
    
	INSERT INTO report (category_id, finish_date, result, description)
    VALUES (category_id_in, finish_date_in, result_in, description_in);
    
    SET report_id_new = (
		SELECT report_id FROM report 
		WHERE category_id = category_id_in AND finish_date = finish_date_in 
		AND result = result_in AND description = description_in ORDER BY report_id LIMIT 1
    );
    IF report_id_new = NULL THEN 
		RETURN 0;
	END IF;
    
    INSERT INTO file_storage (report_id, client_id)
    VALUES (report_id_new, client_id_in);
    
    SET file_storage_id = (
		SELECT file_storage_id FROM file_storage
        WHERE report_id = report_id_new AND client_id = client_id_in
        ORDER BY file_storage_id LIMIT 1
    );
    IF file_storage_id = NULL THEN 
		RETURN 0;
    END IF;
    
RETURN 1;
END;

