create
    definer = alexey@`%` procedure selectClientByNumber(IN number text)
BEGIN
	SELECT client_id, balance, phone_number, account_state 
    FROM client WHERE phone_number = number 
    ORDER BY client_id LIMIT 1;
END;

