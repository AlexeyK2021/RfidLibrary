create
    definer = alexey@`%` procedure selectTariffByNumber(IN number text)
BEGIN
SELECT * FROM tariff WHERE tariff_id = (
    SELECT tariff_id FROM client 
    WHERE phone_number = number
    ORDER BY tariff_id
);
END;

