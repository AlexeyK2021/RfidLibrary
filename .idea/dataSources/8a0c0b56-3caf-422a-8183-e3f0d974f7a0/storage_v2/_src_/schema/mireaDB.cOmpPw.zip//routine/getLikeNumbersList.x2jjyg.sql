create
    definer = alexey@`%` procedure getLikeNumbersList(IN part_phone_number text)
BEGIN
	SELECT phone_number FROM client 
    WHERE phone_number LIKE part_phone_number;
END;

