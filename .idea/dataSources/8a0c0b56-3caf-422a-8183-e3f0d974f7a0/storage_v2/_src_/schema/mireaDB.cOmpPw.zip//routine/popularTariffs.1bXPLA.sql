create
    definer = alexey@`%` procedure popularTariffs()
BEGIN
SELECT tariff.name, COUNT(*) AS count 
FROM client 
JOIN tariff on client.tariff_id = tariff.tariff_id 
GROUP BY client.tariff_id 
ORDER BY count DESC;
END;

