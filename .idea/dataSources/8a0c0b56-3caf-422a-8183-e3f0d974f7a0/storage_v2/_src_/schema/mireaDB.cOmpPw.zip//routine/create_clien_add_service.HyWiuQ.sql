create
    definer = alexey@`%` function create_clien_add_service(add_service int, client_id int) returns int deterministic
BEGIN
	DECLARE time DATETIME;
    SET time = NOW();
    
	INSERT INTO client_add_service(add_service, client_id, fisnish_date)
	VALUE (add_service, client_id, time);
RETURN 1;
END;

