create
    definer = alexey@`%` procedure selectPersonalInfoByNumber(IN number text)
BEGIN
SELECT * FROM personal_info WHERE client_id = (
	SELECT client_id FROM client 
	WHERE phone_number = number
	ORDER BY client_id LIMIT 1
);
END;

