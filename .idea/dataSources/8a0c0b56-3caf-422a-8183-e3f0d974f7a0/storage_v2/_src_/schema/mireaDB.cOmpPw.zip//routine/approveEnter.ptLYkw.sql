create
    definer = alexey@`%` procedure approveEnter(IN login text, IN passwd text)
BEGIN
	SELECT phone_number FROM client WHERE client_id = (
		SELECT client_id FROM personal_info 
        WHERE login = login AND password = passwd 
        ORDER BY client_id LIMIT 1
    );
END;

