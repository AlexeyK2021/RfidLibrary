create
    definer = alexey@`%` procedure get5numbers()
BEGIN
	SELECT new_random_number() as phone_number
    UNION
    SELECT new_random_number() as phone_number
    UNION
    SELECT new_random_number() as phone_number
    UNION
    SELECT new_random_number() as phone_number
    UNION
    SELECT new_random_number() as phone_number;
END;

