create
    definer = alexey@`%` procedure seelctTariffByNumber(IN phone_number text)
BEGIN
SELECT * FROM tariff WHERE tariff_id = (
    SELECT tariff_id FROM client 
    WHERE phone_number = phone_number
);
END;

