create
    definer = alexey@`%` procedure getClientInfoByPhoneNumber(IN phone_number text)
BEGIN
	SELECT client.client_id, personal_info.full_name, tariff.name as Tariff_name, client.balance, client.phone_number 
    FROM client JOIN personal_info ON personal_info.client_id = client.client_id 
    JOIN tariff ON tariff.tariff_id = client.tariff_id 
    WHERE client.phone_number = phone_number
    ORDER BY client.client_id;
END;

