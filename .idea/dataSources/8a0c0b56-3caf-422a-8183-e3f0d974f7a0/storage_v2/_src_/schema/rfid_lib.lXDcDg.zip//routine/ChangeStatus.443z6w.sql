create
    definer = root@localhost function ChangeStatus(rfid_Vis int, rfid_Book int) returns int deterministic reads sql data
BEGIN
DECLARE ID INT;
DECLARE IDV INT;
IF EXISTS (SELECT * FROM Book where rfid_B = rfid_Book) then
	SELECT id_B FROM Book WHERE rfid_B = rfid_Book INTO ID;
    IF rfid_Vis = -1 then
		IF (SELECT isTaken FROM Book WHERE id_B = ID) = 0 THEN
			UPDATE Book SET Visitor_id_V = 0 WHERE id_B = ID;
            UPDATE Book SET isTaken = 0 WHERE id_B = ID;
		ELSE
			SIGNAL sqlstate '45000' SET message_text = "Book already has been returned!";
        END IF;
	ELSE 
		IF (SELECT isTaken FROM Book WHERE id_B = ID) = 1 THEN
			SIGNAL sqlstate '45000' SET message_text = "Book already has been borrowed!";
		ELSE
			IF EXISTS (SELECT * FROM Visitor where rfid_V = rfid_Vis) then
				SELECT id_V FROM Visitor WHERE rfid_V = rfid_Vis INTO IDV;
					UPDATE Book SET Visitor_id_V = IDV WHERE id_B = ID;
					UPDATE Book SET isTaken = 1 WHERE id_B = ID;
			ELSE
				SIGNAL sqlstate '45000' SET message_text = "User does not exist in database!";
			END IF;
		END IF;
	END IF;
ELSE
	SIGNAL sqlstate '45000' SET message_text = "This book is not available now or not in stock!";
END IF;
RETURN 0;
END;

